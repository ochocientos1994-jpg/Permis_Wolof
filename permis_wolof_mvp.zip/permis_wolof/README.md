# Permis Wolof — MVP Android (source Flutter)

## État
Prototype de départ version 0.1.0. Il contient une interface trilingue, un mini quiz fonctionnel, la sauvegarde locale de la progression et une première page de familles de panneaux.

## Important avant publication
- Les 3 questions sont des exemples pédagogiques originaux, pas des questions officielles DGT.
- Les traductions wolof sont des brouillons et doivent être relues/corrigées par un locuteur natif connaissant le vocabulaire routier.
- Le mode « examen blanc » est provisoire : il utilise actuellement 3 questions de démonstration. Il ne doit pas être présenté comme une simulation conforme tant que la banque validée, la durée et les règles de notation applicables ne sont pas intégrées.
- Les images officielles des panneaux et les médias ne sont pas encore inclus. Vérifier les droits d'utilisation avant intégration.
- L'application n'est ni affiliée ni approuvée par la DGT.

## Lancer le projet
1. Installer Flutter SDK et Android Studio.
2. Dans ce dossier : `flutter pub get`
3. Connecter un téléphone Android avec le débogage USB activé ou démarrer un émulateur.
4. `flutter run`
5. Pour générer un APK de test : `flutter build apk --debug` (ou `--release` après configuration de signature).

## Structure
- `lib/main.dart` : interface et logique du prototype.
- `assets/data/questions.json` : questions trilingues et statut de validation.

## Prochaines étapes
1. Valider le périmètre initial : permis B.
2. Faire relire les textes wolof par un locuteur natif.
3. Construire une banque de questions originales, sourcées et révisées par un professionnel de la formation routière.
4. Intégrer les signaux et visuels avec droits vérifiés.
5. Implémenter un véritable examen blanc de 30 questions, chronométré et paramétré selon les exigences DGT en vigueur.
6. Tester accessibilité, mode hors ligne, exactitude et stabilité sur plusieurs appareils Android.
